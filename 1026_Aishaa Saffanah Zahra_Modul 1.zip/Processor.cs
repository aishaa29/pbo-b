﻿// See https://aka.ms/new-console-template for more information

//BagianProcessor
namespace Tugas1PR
{ 

    //Class induk
    class Processor
    {
        public string Merk;
        public string Tipe;

        public string getMerk()
        {
            return Merk;
        }
        public string getTipe()
        {
            return Tipe;
        }
        public Processor(string Merk, string Tipe)
        {
            this.Merk = Merk;
            this.Tipe = Tipe;
        }
    }

    // Class anak dari Processor
    class Intel : Processor
    {
        public Intel(string Merk, string Tipe) : base (Merk, Tipe)
        {
            Merk = "Intel";
        }
    }

    class AMD : Processor
    {
        public AMD(string Merk, string Tipe) : base (Merk, Tipe)
        {
            Merk = "AMD";
        }
    }
    
    // Class anak dari Intel
    class Corei3 : Intel
    {
        public Corei3(string Merk, string Tipe) : base (Merk, Tipe)
        {
            Tipe = "Corei3";
        }
    }

    class Corei5 : Intel
    {
        public Corei5(string Merk, string Tipe) : base(Merk, Tipe)
        {
            Tipe = "Corei5";
        }
    }

    class Corei7 : Intel
    {
        public Corei7(string Merk, string Tipe) : base(Merk, Tipe)
        {
            Tipe = "Corei7";
        }
    }

    // Class anak dari AMD
    class Ryzen : AMD
    {
        public Ryzen(string Merk, string Tipe) : base (Merk, Tipe)
        {
            Tipe = "RAYZEN";
        }
    }

    class Athlon : AMD
    {
        public Athlon(string Merk, string Tipe) : base (Merk, Tipe)
        {
            Tipe = "ATHLON";
        }
    }

}
