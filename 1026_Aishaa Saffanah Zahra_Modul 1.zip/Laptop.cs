﻿using BagianVGA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tugas1PR;

namespace BagianLaptop
{
    class Laptop
    {
        public string Merk;
        public string Tipe;
        public VGA vga ;
        public Processor processor;

        public Laptop(string Merk, string Tipe, VGA vga, Processor processor)
        {
            this.Merk = Merk;
            this.Tipe = Tipe;
            this.vga = vga;
            this.processor = processor;
        }

        public void LaptopDinyalakan()
        {
            Console.WriteLine($"Laptop {this.Merk} {this.Tipe} menyala");
        }

        public void LaptopDimatikan()
        {
            Console.WriteLine($"Laptop {this.Merk} {this.Tipe} mati");
        }
    }

    // class anak dari laptop
    class ASUS : Laptop
    {
        public ASUS(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "ASUS";
        }
    }

    class ACER : Laptop
    {
        public ACER(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "ACER";
        }
    }

    class Lenovo : Laptop
    {
        public Lenovo(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "Lenovo";
        }
    }

    //class anak dari asus
    class ROG : ASUS
    {
        public ROG(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "ROG";
        }
    }

    class Vivobook : ASUS
    {
        public Vivobook(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "Vivobook";
        }

        public void Ngoding()
        {
            Console.WriteLine("Ctakk ctakk ctakkk, error lagi!");
        }
    }

    //class anak dari acer
    class Swift : ACER
    {
        public Swift(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "Swift";
        }
    }

    class Predator : ACER
    {
        public Predator(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "Predator";
        }

        public void BermainGame()
        {
            Console.WriteLine($"Laptop {this.Merk} {this.Tipe} sedang memainkan game");
        }
    }

    //class anak dari Lenovo
    class IdeaPad : Lenovo
    {
        public IdeaPad(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "IdeaPad";
        }
    }

    class Legion : Lenovo
    {
        public Legion(string Merk, string Tipe, VGA vga, Processor processor) : base(Merk, Tipe, vga, processor)
        {
            Merk = "Legion";
        }
    }
}
