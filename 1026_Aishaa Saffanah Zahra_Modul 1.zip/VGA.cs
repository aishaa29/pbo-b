﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BagianVGA
{
    //class induk
    class VGA
    {
        public string Merk;
        public VGA(string Merk)
        {
            this.Merk = Merk;
        }
    }

    // claass anak dari VGA
    class Nvidia : VGA
    {
        public Nvidia(string Merk) : base(Merk)
        {
            Merk = "Nvidia";
        }
    }

    class AMD : VGA
    {
        public AMD(string Merk) : base(Merk)
        {
            Merk = "AMD";
        }
    }
}
