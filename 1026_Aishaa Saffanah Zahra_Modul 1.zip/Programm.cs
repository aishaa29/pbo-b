﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BagianLaptop;
using BagianVGA;
using Tugas1PR;

namespace BagianProgram
{
    internal class Programm
    {
        static void Main(string[] args)
        {
            Console.WriteLine("JAWABAN");
            Console.WriteLine("-----------");

            //Jawaban soal nomo 1
            VGA v2 = new VGA("AMD");
            Processor p2 = new Processor("AMD", "Ryzen");
            Laptop laptop2 = new Laptop("Lenovo", "IdeaPad", v2, p2);
            ////Memanggil method
            laptop2.LaptopDimatikan();
            laptop2.LaptopDinyalakan();

            //JAWABAN SOALN NOMOR 2
           
            VGA v1 = new VGA("Nvdia");
            Processor p1 = new Processor("Intel", "CoreI5");
            Vivobook laptop1 = new Vivobook("Asus", "Vivobook", v1, p1);
            ////Memanggil method
            laptop1.Ngoding();

            ////Soal nomer 3
            VGA v1 = new VGA("Nvidia");
            Processor p1 = new Processor("Intel", "CoreI5");
            Laptop laptop1 = new Laptop("Asus", "Vivobook", v1, p1);
            Console.WriteLine("Merk Vga: " + laptop1.vga.Merk + 
                "\n" + "Merk Processor: " + laptop1.processor.Merk + 
                "\n" + "Tipe Processor: " + laptop1.processor.Tipe);

            ////Soal nomer 4
            VGA v2 = new VGA("AMD");
            Processor p3 = new Processor("Intel", "CoreI7");
            Predator predator1 = new Predator("Acer", "Predator", v2, p3);
            ////Memanggil method
            predator1.BermainGame();

            ////Soal nomer 5 
            VGA v2 = new VGA("AMD");
            Processor p3 = new Processor("Intel", "CoreI7");
            ACER acer = new Predator("Acer", "Predator", v2, p3);
            ////Memanggil method
            acer.BermainGame();
        }
    }
}
